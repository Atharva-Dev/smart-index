Smart Index test file (zip)
